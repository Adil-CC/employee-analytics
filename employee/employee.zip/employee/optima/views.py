from django.shortcuts import render, redirect
from optima import *
from .models import user

def index(request):
    return render(request,'index.html')
def login(request):
    name = request.POST['name']
    passs = request.POST['passs']
    res = user.objects.filter(name=name, passs=pss)
    if res.exists():
        return redirect('/employee')
  

def employee(request):
    return render(request,'emp.html')